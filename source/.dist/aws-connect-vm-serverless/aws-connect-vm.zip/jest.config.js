module.exports = {
    testEnvironment: 'node',
    moduleFileExtensions: ['js'],
    testMatch: ['**/tests/*.test.js'],
    testPathIgnorePatterns: ['dist/'],
    testEnvironment: 'node',
  };